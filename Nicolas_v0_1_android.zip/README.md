# Nicolás v0.1

Primer prototipo Android del proyecto Nicolás.

## Objetivo
Construir el núcleo mínimo funcional:
- identidad de Nicolás
- interfaz de chat
- Core desacoplado
- memoria inicial
- Security Core
- AIManager intercambiable
- arquitectura preparada para crecer

## Estado
El proveedor de IA es actualmente un DemoAIManager. El siguiente paso es conectarlo al proveedor de IA real elegido, manteniendo NicolasCore independiente del proveedor.

## Próximas capas
1. Persistencia real de memoria
2. Context Engine
3. Decision Engine
4. Activity Manager
5. proveedor de IA real
6. voz
7. visión
8. Internet y herramientas
9. Android Bridge
