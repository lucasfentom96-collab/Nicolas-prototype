package com.braian.nicolas.security

class SecurityCore {
    fun canRemember(): Boolean = true
}
