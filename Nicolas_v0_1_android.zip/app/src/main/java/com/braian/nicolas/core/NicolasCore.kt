package com.braian.nicolas.core

import com.braian.nicolas.ai.AIManager
import com.braian.nicolas.memory.MemoryEngine
import com.braian.nicolas.security.SecurityCore

class NicolasCore(
    private val aiManager: AIManager,
    private val memoryEngine: MemoryEngine,
    private val securityCore: SecurityCore
) {
    suspend fun respond(input: String): String {
        val normalized = input.trim()
        if (normalized.isBlank()) return "Decime qué hacemos, Braian."

        if (normalized.contains("recordá", ignoreCase = true) ||
            normalized.contains("recuerda", ignoreCase = true)) {
            if (!securityCore.canRemember()) {
                return "No tengo permiso para guardar ese recuerdo."
            }
            memoryEngine.remember(normalized)
            return "Listo, Braian. Lo guardé como recuerdo de esta conversación."
        }

        val context = memoryEngine.relevantContext(normalized)
        return aiManager.generate(normalized, context)
    }
}
