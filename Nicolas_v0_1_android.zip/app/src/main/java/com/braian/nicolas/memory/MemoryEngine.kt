package com.braian.nicolas.memory

class MemoryEngine {
    private val memories = mutableListOf<String>()

    fun remember(text: String) {
        memories += text
    }

    fun relevantContext(query: String): String {
        if (memories.isEmpty()) return ""
        return memories.takeLast(5).joinToString("\n")
    }
}
