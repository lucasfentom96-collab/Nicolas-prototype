package com.braian.nicolas.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.braian.nicolas.ai.DemoAIManager
import com.braian.nicolas.core.NicolasCore
import com.braian.nicolas.memory.MemoryEngine
import com.braian.nicolas.security.SecurityCore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatMessage(
    val text: String,
    val fromUser: Boolean
)

class NicolasViewModel : ViewModel() {
    private val core = NicolasCore(
        aiManager = DemoAIManager(),
        memoryEngine = MemoryEngine(),
        securityCore = SecurityCore()
    )

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return

        _messages.value = _messages.value + ChatMessage(clean, true)

        viewModelScope.launch {
            val response = core.respond(clean)
            _messages.value = _messages.value + ChatMessage(response, false)
        }
    }
}
