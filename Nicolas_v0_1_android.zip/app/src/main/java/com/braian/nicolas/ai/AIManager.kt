package com.braian.nicolas.ai

interface AIManager {
    suspend fun generate(input: String, context: String): String
}

/**
 * Proveedor temporal para v0.1.
 * Será reemplazado por el proveedor de IA elegido sin modificar NicolasCore.
 */
class DemoAIManager : AIManager {
    override suspend fun generate(input: String, context: String): String {
        return "Soy Nicolás, Braian. Recibí: "$input"\n\n" +
            "Mi conexión con un modelo de IA todavía está preparada como módulo independiente."
    }
}
