package com.braian.nicolas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.lifecycle.viewmodel.compose.viewModel
import com.braian.nicolas.ui.NicolasViewModel
import com.braian.nicolas.ui.NicolasScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    val vm: NicolasViewModel = viewModel()
                    NicolasScreen(vm)
                }
            }
        }
    }
}
